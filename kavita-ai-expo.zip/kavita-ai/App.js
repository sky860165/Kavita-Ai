import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  StyleSheet, KeyboardAvoidingView, Platform, Dimensions,
  ScrollView, Alert
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const Stack = createStackNavigator();
const { width } = Dimensions.get('window');

const getBaseUrl = async () => {
  const url = await AsyncStorage.getItem('SERVER_URL');
  return url || 'http://192.168.1.100:8000';
};

const kavitaApi = {
  chat: async (message) => {
    try {
      const baseUrl = await getBaseUrl();
      const response = await axios.post(`${baseUrl}/chat`, {
        message,
        user_id: 'mobile_user',
        voice: false
      });
      return response.data;
    } catch (error) {
      return {
        response: "Sorry baby, network issue aa raha hai 😢. Please check your server connection.",
        mood: "sad",
        affection_level: 50,
        pet_name: "baby"
      };
    }
  }
};

function ChatScreen({ navigation }) {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      text: 'Haan baby! Main Kavita hun 💕\nTumse baat karke bahut khushi ho rahi hai!',
      sender: 'kavita',
      mood: 'happy'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const flatListRef = useRef(null);

  const getMoodEmoji = (mood) => {
    const moods = {
      happy: '😊', romantic: '😘', jealous: '😤',
      sad: '😢', worried: '😟', angry: '😠',
      forgiving: '🥺', missing: '🥰'
    };
    return moods[mood] || '😊';
  };

  const sendMessage = useCallback(async () => {
    if (!inputText.trim()) return;

    const userMsg = {
      id: Date.now().toString(),
      text: inputText.trim(),
      sender: 'user'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    const response = await kavitaApi.chat(userMsg.text);

    const kavitaMsg = {
      id: (Date.now() + 1).toString(),
      text: response.response,
      sender: 'kavita',
      mood: response.mood
    };

    setMessages(prev => [...prev, kavitaMsg]);
    setIsTyping(false);

    Speech.stop();
    Speech.speak(response.response, {
      language: 'hi-IN',
      pitch: 1.1,
      rate: 0.9
    });
  }, [inputText]);

  const renderMessage = ({ item }) => {
    const isUser = item.sender === 'user';

    return (
      <View style={[
        styles.messageContainer,
        isUser ? styles.userContainer : styles.kavitaContainer
      ]}>
        {!isUser && (
          <View style={styles.avatarContainer}>
            <Text style={styles.avatarEmoji}>{getMoodEmoji(item.mood)}</Text>
          </View>
        )}

        <View style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.kavitaBubble
        ]}>
          <Text style={[
            styles.messageText,
            isUser ? styles.userText : styles.kavitaText
          ]}>
            {item.text}
          </Text>
        </View>

        {isUser && (
          <View style={styles.avatarContainer}>
            <Text style={styles.avatarEmoji}>👤</Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.headerActions}>
        <TouchableOpacity 
          style={styles.headerButton}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.headerButtonText}>⚙️ Settings</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.messageList}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
      />

      {isTyping && (
        <View style={styles.typingContainer}>
          <Text style={styles.typingText}>Kavita typing 💕💕💕</Text>
        </View>
      )}

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Message your Kavita..."
          placeholderTextColor="#999"
          multiline
          maxLength={500}
        />
        <TouchableOpacity 
          style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
          onPress={sendMessage}
          disabled={!inputText.trim()}
        >
          <Text style={styles.sendText}>💌</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

function SettingsScreen() {
  const [serverUrl, setServerUrl] = useState('http://192.168.1.100:8000');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const url = await AsyncStorage.getItem('SERVER_URL');
    if (url) setServerUrl(url);
  };

  const saveSettings = async () => {
    await AsyncStorage.setItem('SERVER_URL', serverUrl);
    Alert.alert('💕 Saved!', 'Settings saved successfully baby!');
  };

  const testConnection = async () => {
    try {
      const response = await fetch(`${serverUrl}/health`);
      const data = await response.json();
      Alert.alert('✅ Connected!', `Kavita says: ${data.status}`);
    } catch (error) {
      Alert.alert('❌ Error', 'Cannot connect. Check your PC IP.');
    }
  };

  return (
    <ScrollView style={styles.settingsContainer}>
      <Text style={styles.settingsTitle}>⚙️ Kavita Settings</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🌐 Backend Server</Text>
        <Text style={styles.hint}>
          Apne PC ka IP daalo. Same WiFi pe hone chahiye.
        </Text>
        <TextInput
          style={styles.input}
          value={serverUrl}
          onChangeText={setServerUrl}
          placeholder="http://192.168.1.100:8000"
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.testButton} onPress={testConnection}>
          <Text style={styles.testButtonText}>🔄 Test Connection</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>📖 How to setup:</Text>
        <Text style={styles.infoText}>
          1. PC pe backend run karo: python main.py{'
'}
          2. PC ka IP check karo: ipconfig/ifconfig{'
'}
          3. Woh IP yahan daalo{'
'}
          4. Test Connection dabao
        </Text>
      </View>

      <TouchableOpacity style={styles.saveButton} onPress={saveSettings}>
        <Text style={styles.saveText}>💾 Save Settings</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

export default function App() {
  return (
    <>
      <StatusBar style="light" backgroundColor="#FF6B9D" />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: '#FF6B9D' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: 'bold' }
          }}
        >
          <Stack.Screen 
            name="Chat" 
            component={ChatScreen}
            options={{ title: '💕 Kavita AI' }}
          />
          <Stack.Screen 
            name="Settings" 
            component={SettingsScreen}
            options={{ title: '⚙️ Settings' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF0F5'
  },
  headerActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingVertical: 10,
    backgroundColor: '#FF6B9D',
    paddingTop: Platform.OS === 'ios' ? 50 : 10,
    paddingHorizontal: 15
  },
  headerButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20
  },
  headerButtonText: {
    color: '#fff',
    fontWeight: '600'
  },
  messageList: {
    padding: 15,
    paddingBottom: 20
  },
  messageContainer: {
    flexDirection: 'row',
    marginVertical: 5,
    alignItems: 'flex-end',
    maxWidth: width * 0.85
  },
  userContainer: {
    alignSelf: 'flex-end',
    flexDirection: 'row-reverse'
  },
  kavitaContainer: {
    alignSelf: 'flex-start'
  },
  avatarContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFE4EC',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5
  },
  avatarEmoji: {
    fontSize: 20
  },
  bubble: {
    maxWidth: width * 0.65,
    padding: 12,
    borderRadius: 20,
    elevation: 2
  },
  userBubble: {
    backgroundColor: '#FF6B9D',
    borderBottomRightRadius: 5
  },
  kavitaBubble: {
    backgroundColor: '#fff',
    borderBottomLeftRadius: 5
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22
  },
  userText: {
    color: '#fff'
  },
  kavitaText: {
    color: '#333'
  },
  typingContainer: {
    paddingHorizontal: 20,
    paddingVertical: 5
  },
  typingText: {
    fontSize: 14,
    color: '#FF6B9D',
    fontStyle: 'italic'
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#FFE4EC',
    alignItems: 'center'
  },
  input: {
    flex: 1,
    backgroundColor: '#f8f8f8',
    borderRadius: 25,
    paddingHorizontal: 18,
    paddingVertical: 12,
    fontSize: 16,
    maxHeight: 100,
    color: '#333'
  },
  sendButton: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    width: 50,
    height: 50,
    backgroundColor: '#FF6B9D',
    borderRadius: 25
  },
  sendButtonDisabled: {
    backgroundColor: '#ccc'
  },
  sendText: {
    fontSize: 22
  },
  settingsContainer: {
    flex: 1,
    backgroundColor: '#FFF0F5',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 20
  },
  settingsTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6B9D',
    marginBottom: 30
  },
  section: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 20
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10
  },
  hint: {
    fontSize: 13,
    color: '#999',
    marginBottom: 15
  },
  testButton: {
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center'
  },
  testButtonText: {
    color: '#fff',
    fontWeight: 'bold'
  },
  infoBox: {
    backgroundColor: '#E3F2FD',
    padding: 18,
    borderRadius: 15,
    marginBottom: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3'
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1976D2',
    marginBottom: 10
  },
  infoText: {
    fontSize: 14,
    color: '#555',
    lineHeight: 22
  },
  saveButton: {
    backgroundColor: '#FF6B9D',
    padding: 18,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 30
  },
  saveText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold'
  }
});
