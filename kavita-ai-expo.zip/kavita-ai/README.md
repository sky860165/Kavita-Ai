# 💕 Kavita AI Mobile App

Built with Expo - Easy APK generation!

## Setup

1. Create Expo account: https://expo.dev/signup
2. Generate token: https://expo.dev/settings/access-tokens
3. Add token to GitHub Secrets as `EXPO_TOKEN`
4. Push code, APK builds automatically!

## Manual Build

```bash
npm install -g eas-cli
eas build --platform android --profile preview
```
